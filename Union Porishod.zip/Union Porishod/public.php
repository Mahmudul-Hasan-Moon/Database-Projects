<?php

require('header.php');
?>


<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_POST['submit'])){
    	$birth_id = stripslashes($_REQUEST['birth_id']);
		$birth_id = mysqli_real_escape_string($con,$birth_id);
		$name = stripslashes($_REQUEST['name']); // removes backslashes
		$name = mysqli_real_escape_string($con,$name); //escapes special characters in a string
		$fathers_name = stripslashes($_REQUEST['fathers_name']); // removes backslashes
		$fathers_name = mysqli_real_escape_string($con,$fathers_name); //escapes special characters in a string
		$mothers_name = stripslashes($_REQUEST['mothers_name']); // removes backslashes
		$mothers_name = mysqli_real_escape_string($con,$mothers_name); //escapes special characters in a string
		$address = stripslashes($_REQUEST['address']);
		$address = mysqli_real_escape_string($con,$address);
		$nid = stripslashes($_REQUEST['nid']);
		$nid = mysqli_real_escape_string($con,$nid);
		$ward_no = stripslashes($_REQUEST['ward_no']);
		$ward_no = mysqli_real_escape_string($con,$ward_no);
		$profession = stripslashes($_REQUEST['profession']);
		$profession = mysqli_real_escape_string($con,$profession);
		$annual_income = stripslashes($_REQUEST['annual_income']); // removes backslashes
		$annual_income = mysqli_real_escape_string($con,$annual_income); //escapes special characters in a string
		$property_amount = stripslashes($_REQUEST['property_amount']); // removes backslashes
		$property_amount = mysqli_real_escape_string($con,$property_amount); //escapes special characters in a string
		

	
        $query = "INSERT into `public` (birth_id,name,fathers_name,mothers_name,address, nid,ward_no,profession, annual_income,property_amount) VALUES ('$birth_id','$name','$fathers_name','$mothers_name','$address','$nid','$ward_no','$profession'
         , '$annual_income', '$property_amount')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>Data inserted successfully.</h3></div>";
        }
    }else{
?>
<div class="form">
<h1>Insert Employees Information</h1>
<form name="registration" action="" method="post">
<input type="text" name="birth_id" placeholder="Birth ID" required />
<input type="text" name="name" placeholder="Name" required />
<input type="text" name="fathers_name" placeholder="Fathers Name" required />
<input type="text" name="mothers_name" placeholder="Mothers Name" required />
<input type="text" name="address" placeholder="Address" required />
<input type="text" name="nid" placeholder="National ID" required />
<input type="text" name="ward_no" placeholder="Ward No" required />
<input type="text" name="profession" placeholder="Profession" required />
<input type="text" name="annual_income" placeholder="Annual Income" required />
<input type="text" name="property_amount" placeholder="Property Amount" required />
<input type="submit" name="submit" value="Register" />
</form>

</div>
<?php } ?>
<body style="background:url(b.jpg);">

</body>
</html>
