<?php
include("auth.php"); 
//require('header.php');

?>
<!-- <link rel="stylesheet" href="css/style.css" />
<meta charset="utf-8">

<ul>
  <li><a class="active" href="index.php">Home</a></li>
  <li><a href="insert.php">Public Table</a></li>
  <li><a href="employee.php">Employee Table</a></li>
  <li><a href="member.php">Member Table</a></li>
  <li><a href="project.php">Projects</a></li>
</ul>
<body style="background:url(b.jpg);">

</body> -->