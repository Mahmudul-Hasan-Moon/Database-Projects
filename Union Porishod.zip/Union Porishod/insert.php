<?php

require('header.php');

?>


<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_POST['submit'])){
    	$birthid = stripslashes($_REQUEST['birthid']);
		$birthid = mysqli_real_escape_string($con,$birthid);
		$name = stripslashes($_REQUEST['name']); // removes backslashes
		$name = mysqli_real_escape_string($con,$name); //escapes special characters in a string
		$fathers_name = stripslashes($_REQUEST['fathers_name']);
		$fathers_name = mysqli_real_escape_string($con,$fathers_name);
		$mothers_name = stripslashes($_REQUEST['mothers_name']);
		$mothers_name = mysqli_real_escape_string($con,$mothers_name);
		$address = stripslashes($_REQUEST['address']); // removes backslashes
		$address = mysqli_real_escape_string($con,$address); //escapes special characters in a string
		$nid = stripslashes($_REQUEST['nid']);
		$nid = mysqli_real_escape_string($con,$nid);
		$profession = stripslashes($_REQUEST['profession']);
		$profession = mysqli_real_escape_string($con,$profession);
		$annual_income = stripslashes($_REQUEST['annual_income']); // removes backslashes
		$annual_income = mysqli_real_escape_string($con,$annual_income); //escapes special characters in a string
		$property_amount = stripslashes($_REQUEST['property_amount']);
		$property_amount = mysqli_real_escape_string($con,$property_amount);
		
        //echo $birthid;
        $query = "INSERT into `public` (birth_id,name, fathers_name, mothers_name, address, nid, profession, annual_income, property_amount) VALUES (''$birthid',$name', '$fathers_name', '$mothers_name', '$address', '$nid', '$profession', '$annual_income','$property_amount')";
        //var_dump($query);
        $result = mysqli_query($con,$query);
        var_dump($result);
        if($result){
            echo "<div class='form'><h3>Data inserted successfully.</h3></div>";
        }
    }else{
?>
<div class="form">
<h1>Insert Public Information</h1>
<form name="registration" action="insert.php" method="post" class="input-form">
<input type="text" name="birthid" placeholder="Birth ID" required />
<input type="text" name="name" placeholder="Name" required />
<input type="text" name="fathers_name" placeholder="Fathers Name" required />
<input type="text" name="mothers_name" placeholder="Mothers Name" required />
<input type="text" name="address" placeholder="Address" required />
<input type="text" name="nid" placeholder="National ID"  />
<input type="text" name="profession" placeholder="Profession" required />
<input type="text" name="annual_income" placeholder="Annul Income" required />
<input type="text" name="property_amount" placeholder="Property Income" required />
<input type="submit" name="submit" value="Register" />
</form>

</div>
<?php } ?>

