

<title>Welcome Home</title>
<link rel="stylesheet" href="css/style.css" />
<meta charset="utf-8">
<div class="image">
	<center><h1>3 No. Borobil Union Porishod</h1></center>
	<img src="union.jpg" class="logimage">
	<link href="insert.css" rel="stylesheet" type="text/css"/>
</div>


<?php

require('header.php');
?>


<div class="fix container">
<h2>About the union</h2>
<p>Barabil Union Parishod is in Gangachara upozilla in Rangpur District.
 It is 3 no union of the Upozilla and the first model union also. The union 
 is peaceful and 8543 acre arean and 17004 number of male and 15442 number of
 female are in the union. The rate of education is 55.65% is the highest in the
 upozilla. The union is divided into 9 wards and rules by the local goverment part of bangladesh.
 Gangachara Upazila (rangpur district) area 272.28 sq km, located in between 25°48' and 25°57' north latitudes and in between 89°05' and 89°21' east longitudes. It is bounded by kaliganj (lalmonirhat) and jaldhaka upazilas on the north, rangpur sadar and kaunia upazilas on the south, aditmari and lalmonirhat sadar upazilas on the east, kishoreganj (nilphamari) and taraganj upazilas on the west. The town is famous for tobacco business. 
 History of the War of Liberation In the middle of August 1971, a Pak soldier entered into Gangachara and chased a young girl and her father. The victims, finding no way to safety, jumped into the river and died. In the month of October, two Pak soldiers and five razakars were killed in an encounter with the guerrillas of Mujib Bahini. Later on, the Pak army launched attack on the innocent people and killed 17 pious Muslims entering into the Taltala Mosque. About 212 razakars surrendered to the Gangachara police station on 13 December.'

Marks of the War of Liberation Memorial monument 1 (Mahipur).

Religious institutions Mosque 305, temple 48.

Literacy rate and educational institutions Average literacy 32.95%; male 37.58%, female 27.93%. Educational institutions: college 8, secondary school 31, primary school 182, madrasa 23. Noted educational institutions: Gajaghanta High School and College (1906), Pakuria Sharif Bilateral High School (1919).

Cultural organisations Club 56, cinema hall 2, theatre group 2.
 </p><br><br>
</div>
				<footer>
					<div class="footer">
					
							<h2>Categories:</h2>
							<ul>
								<li><a href="https://lgd.gov.bd/">Local Government</a></li>
								<li><a href="#">Facebook Page</a></li>
								<li><a href="https://www.youtube.com/">Youtube</a></li>
								<li><a href="d.html">Developers</a></li>			
							</ul>
					</div>
				</footer>
		</div>



