<?php
include("auth.php"); 
//require('header.php');

?>
<link rel="stylesheet" href="css/style.css" />
<meta charset="utf-8">

<ul>
  <li><a class="active" href="index.php">Home</a></li>
  <li><a href="#">All Public Information</a></li>
  <li><a href="#">Kabikha</a></li>
  <li><a href="#">VGF</a></li>
  <li><a href="#">Adult Allowance</a></li>
</ul>
<body style="background:url(b.jpg);">

</body>