

<title>Welcome to our Home page</title>
<link rel="stylesheet" href="css/style.css" />
<meta charset="utf-8">
<div class="image">
	<center><h1> !! Welcome To Our Home Page !!  </h1></center>
    <center><h1>Online Doctor Appointment System </h1></center>
	<img src="" class="logimage">
	<link href="insert.css" rel="stylesheet" type="text/css"/>
</div>

<?php

require('header.php');
?>
<br><br>
   

<header>
					<div class="header">
				
							<h2><li><a href="about.php">Facilities available</a></li></h2>
                        
                        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
							
					</div>
				</header>
		
	  
	  <br>
  

  
    
<footer>
					<div class="footer">
				
					
							<h2>Follow us on:</h2>
							<ul>
								<li><a href="#">Twitter</a></li>
								<li><a href="#">Facebook Page</a></li>
								<li><a href="https://www.youtube.com/">Youtube</a></li>		
							</ul>
					</div>
				</footer>
		



