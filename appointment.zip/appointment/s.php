 <?php

require('header.php');
?>


<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_POST['submit'])){
		$name = stripslashes($_REQUEST['name']); // removes backslashes
		$name = mysqli_real_escape_string($con,$name); //escapes special characters in a string
		$category = stripslashes($_REQUEST['category']);
		$category = mysqli_real_escape_string($con,$category);
        $day = stripslashes($_REQUEST['day']);
		$day = mysqli_real_escape_string($con,$day);
		$st = stripslashes($_REQUEST['st']);
		$st = mysqli_real_escape_string($con,$st);
		$et = stripslashes($_REQUEST['et']);
		$et = mysqli_real_escape_string($con,$et);
		

	
        $query = "INSERT into `s` (name,category,day,st,et) VALUES ('$name','$category','$day','$st','$et')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>Data inserted successfully.</h3></div>";
        }
    }else{
?>
<div class="form">
<h1>Book Appointment</h1>
<form name="registration" action="" method="post">
<input type="text" name="name" placeholder="Name" required /><br>
<input type="text" name="category" placeholder="Category" required /><br>
<input type="text" name="day" placeholder="Days" required /><br>
<input type="text" name="st" placeholder="Start Time" required /><br>
<input type="text" name="et" placeholder="End Time" required /><br>
<input type="submit" name="submit" value="Submit" />
</form>

</div>
<?php } ?>
<body style="background:url(b.jpg);">

</body>
</html>
