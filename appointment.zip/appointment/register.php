<?php
require('header.php');
/*if(isset($_SESSION["adminname"])){
 header('Location:index.php');
	}*/
?>

<title>Register</title>
<link rel="stylesheet" href="css/style.css" />


<?php

	require('db.php');
	//session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['username'])){
		
		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		echo $username;
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `register` WHERE username='$username' and password='$password'";
		$result = mysqli_query($con,$query) or die(mysql_error());
		$rows = mysqli_num_rows($result);
		echo $rows;
		var_dump($rows);
        if($rows==1){
			$_SESSION['username'] = $username;
			header("Location: /appointment/p-log.php"); // Redirect user to index.php
            }else{
				echo "<div class='form'><h3>Doctor name or Password is incorrect.</h3><br/>Click here to <a href='register.php'>Register</a></div>";
				}
    }else{
?>
<div class="form">

<h1>Registration Form</h1>
<form name="registration" action="" method="post" 
<input type="text" name="username" placeholder="userame" required /><br>
<input type="password" name="password" placeholder="Password" required /><br><br>
<input type="text" name="name" placeholder="Name" required /><br>
<input type="text" name="address" placeholder="Address" required /><br>
<input type="text" name="age" placeholder="Age" required /><br>
<input type="radio" name="Gender" value="m">Male
<input type="radio" name="Gender" value="f">Female<br><br>
<input type="mail" placeholder="Email" required /><br><br>
<input type="phone" placeholder="Phone_No" required /><br>
<input type="submit" name="submit" value="Register" />
    </form>
    
 <p CLASS="MESSAGE">NOT REGISTERED ? <a href="register.php">REGISTER</a></p>
    <p CLASS="MESSAGE"> ALREADY REGISTERED? <a href="p-log.php">LOG IN </a> 
    </p>

   

<br /><br />

</div>
<?php } ?>
<body style="background:url(pic1.jpg);">

</body>
</html>
