<?php

require('ph.php');
?>


<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_POST['submit'])){
		$name = stripslashes($_REQUEST['name']); // removes backslashes
		$name = mysqli_real_escape_string($con,$name); //escapes special characters in a string
		$address = stripslashes($_REQUEST['address']);
		$address = mysqli_real_escape_string($con,$address);
		$age = stripslashes($_REQUEST['age']);
		$age = mysqli_real_escape_string($con,$age);
		$gender = stripslashes($_REQUEST['gender']);
		$gender = mysqli_real_escape_string($con,$gender);
		$phn_no = stripslashes($_REQUEST['phn_no']);
		$phn_no = mysqli_real_escape_string($con,$phn_no);
		$problem = stripslashes($_REQUEST['problem']);
		$problem = mysqli_real_escape_string($con,$problem);
        $doctor = stripslashes($_REQUEST['doctor']);
		$doctor = mysqli_real_escape_string($con,$doctor);
		$email = stripslashes($_REQUEST['email']); // removes backslashes
		$email = mysqli_real_escape_string($con,$email); //escapes special characters in a string
		$payment = stripslashes($_REQUEST['payment']); // removes backslashes
		$payment = mysqli_real_escape_string($con,$payment); //escapes special characters in a string
		$date = stripslashes($_REQUEST['date']); // removes backslashes
		$date = mysqli_real_escape_string($con,$date); //escapes special characters in a 
		

	
        $query = "INSERT into `patient` (name,address,age,gender,phn_no,problem,doctor,email,payment,date) VALUES ('$name','$address','$age','$gender','$phn_no','$problem','$doctor','$email', '$payment', '$date')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>Your appointment form has been submitted successfully.</h3></div>";
             echo "<div class='form'><h1>You will receive SMS very soon in your phone.</h3></div>";
             echo "<div class='form'><h3>THANKYOU !!!.</h3></div>";
        }
    }else{
?>
<div class="form">
<h1>Book Appointment</h1>
<form name="registration" action="" method="post">
<input type="text" name="name" placeholder="Name" required /><br>
<input type="text" name="address" placeholder="Address" required /><br>
<input type="text" name="age" placeholder="Age" required /><br><br>
<input type="radio" name="gender" value="M">Male
<input type="radio" name="gender" value="F">Female<br>
<input type="text" name="phn_no" placeholder="Phone No" required /><br>
<input type="text" name="problem" placeholder="Problem" required /><br><br>
    
     <div class="doctor">
      <select name="doctor" class = "form-control input-lg" required>
      <option value="">Doctors Available</option>
      <option value="Dr.Prabha (Cardiologist)">Dr.Prabha (Cardiologist)</option>
      <option value="Dr. Sita (Gynocologist)">Dr. Sita (Gynocologist)</option>
      <option value="Dr. Abdi Rehman (Cardiologist)">Dr. Abdi Rehman (Cardiologist)</option>
      <option value="Dr. Mukesh (Medicine)">Dr. Mukesh (Medicine)</option>
      <option value="Dr. Ashok  (Orthopadic)">Dr. Ashok  (Orthopadic)</option>
      <option value="Dr. Anil Kumar (Dermatologist)">Dr. Anil Kumar (Dermatologist)</option>
      <option value="Dr. Shyam (Internal medicine)">Dr. Shyam (Internal medicine)</option>
      <option value="Dr. Rahul (Pediatricians)">Dr. Rahul (Pediatricians)</option>
      <option value="Dr. Hari (Allergists)">Dr. Hari (Allergists)</option>
      <option value="Dr. Neelam (Ophthalmologists)">Dr. Neelam (Ophthalmologists)</option>
      </select>
  </div>
    
<input type="text" name="email" placeholder="E-mail" /><br>
<input type="text" name="payment" placeholder="Payment" required /><br>
<label style="display: block;">Date</label>
<input type="date" name="date" placeholder="Date" required /><br>
<input type="submit" name="submit" value="Submit" />
</form>

</div>
<?php } ?>
<body style="background:url(a1.png);">

</body>
</html>
