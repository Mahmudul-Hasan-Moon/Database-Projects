<?php

require('header.php');
?>


<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_POST['submit'])){
		$name = stripslashes($_REQUEST['name']); // removes backslashes
		$name = mysqli_real_escape_string($con,$name); //escapes special characters in a string
		$address = stripslashes($_REQUEST['address']);
		$address = mysqli_real_escape_string($con,$address);
		$age = stripslashes($_REQUEST['age']);
		$age = mysqli_real_escape_string($con,$age);
		$gender = stripslashes($_REQUEST['gender']);
		$gender = mysqli_real_escape_string($con,$gender);
		$phn_no = stripslashes($_REQUEST['phn_no']);
		$phn_no = mysqli_real_escape_string($con,$phn_no);
		$problem = stripslashes($_REQUEST['problem']);
		$problem = mysqli_real_escape_string($con,$problem);
		$email = stripslashes($_REQUEST['email']); // removes backslashes
		$email = mysqli_real_escape_string($con,$email); //escapes special characters in a string
		$payment = stripslashes($_REQUEST['payment']); // removes backslashes
		$payment = mysqli_real_escape_string($con,$payment); //escapes special characters in a string
		$dat = stripslashes($_REQUEST['dat']); // removes backslashes
		$dat = mysqli_real_escape_string($con,$dat); //escapes special characters in a 
		

	
        $query = "INSERT into `patient` (name,address,age,gender,phn_no,problem,email,payment,dat) VALUES ('$name','$address','$age','$gender','$phn_no','$problem', '$email', '$payment', '$dat')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>Data inserted successfully.</h3></div>";
        }
    }else{
?>
<div class="form">
<h1>Book Appointment</h1>
<form name="registration" action="" method="post">
<input type="text" name="name" placeholder="Name" required /><br>
<input type="text" name="address" placeholder="Address" required /><br>
<input type="text" name="age" placeholder="Age" required /><br>
<input type="text" name="gender" placeholder="Gender" required /><br>
<input type="text" name="phn_no" placeholder="Phone No" required /><br>
<input type="text" name="problem" placeholder="Problem" required /><br>
<input type="text" name="email" placeholder="E-mail" /><br>
<input type="text" name="payment" placeholder="Payment" required /><br>
<label style="display: block;">Date</label>
<input type="date" name="dat" placeholder="Date" required /><br>
<input type="submit" name="submit" value="Submit" />
</form>

</div>
<?php } ?>
<body style="background:url(b.jpg);">

</body>
</html>
