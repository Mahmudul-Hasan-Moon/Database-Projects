<?php
require('header.php');
/*if(isset($_SESSION["adminname"])){
 header('Location:index.php');
	}*/
?>

<title>Login</title>
<link rel="stylesheet" href="css/style.css" />


<?php

	require('db.php');
	//session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['username'])){
		
		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		echo $username;
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `register` WHERE username='$username' and password='$password'";
		$result = mysqli_query($con,$query) or die(mysql_error());
		$rows = mysqli_num_rows($result);
		echo $rows;
		var_dump($rows);
        if($rows==1){
			$_SESSION['username'] = $username;
			header("Location: /appointment/ph.php"); // Redirect user to index.php
            }else{
				echo "<div class='form'><h3>User name or Password is incorrect.</h3><br/>Click here to <a href='p-log.php'>Login</a></div>";
				}
    }else{
?>
<div class="form">

<h1>Patient Login</h1>
<form action="" method="post" name="login">
<input type="text" name="username" placeholder="userame" required /><br>
<input type="password" name="password" placeholder="Password" required />
<p><input name="submit" type="submit" value="Login" /></p>
</form>

<br /><br />

</div>
<?php } ?>
<body style="background:url(pic1.jpg);">

</body>
</html>
