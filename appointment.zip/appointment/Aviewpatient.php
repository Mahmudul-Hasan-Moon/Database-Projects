<?php

require('header.php');
//session_start();
?>


<?php
	require('db.php');?>
<?php 
$sql = 'SELECT * FROM patient';
         $result = mysqli_query($con, $sql);
?>
<!doctype html>
    <html>
    <body>
        <h1 align="center">Patient Details</h1>
        <table border="1" align="center" style="line-height:25px;">
            <tr>
                <th>Serial Number</th>
                <th> Namev</th>
                <th> Address</th>
                <th>Gender</th>
                <th>Phone Number</th>
                <th>Problem</th>
                 <th>Doctor</th>
                <th>E-mail</th>
                <th>Payment</th>
                <th>Date</th>
            </tr>
            <?php

         if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                 ?>
            <tr>
                <td><?php echo $row["Id"];?></td>
                <td><?php echo $row["name"];?></td>
                <td><?php echo $row["address"];?></td>
                <td><?php echo $row["gender"];?></td>
                <td><?php echo $row["phn_no"];?></td>
                <td><?php echo $row["problem"];?></td>
                <td><?php echo $row["doctor"];?></td>
                <td><?php echo $row["email"];?></td>
                <td><?php echo $row["payment"];?></td>
                <td><?php echo $row["date"];?></td>
                </tr>
            <?php
              
            }
         }
            else
            {
                ?>
            <tr>
                <th colspan="2">0 Results :::</th>
            </tr>
            <?php                
               }
            ?>
        </table>
        </body>
</html>
               