<?php
 
require('db.php');
require('header.php');//include auth.php file on all secure pages ?>

<title>Dashboard - Secured Page</title>

<div class="form">
<p>Dashboard</p>
<p>This is another secured page.</p>
<p><a href="index.php">Home</a></p>
<a href="logout.php">Logout</a>
<body style="background:url(b.jpg);">

</body>



