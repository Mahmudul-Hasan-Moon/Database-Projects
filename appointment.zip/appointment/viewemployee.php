<?php

require('header.php');
//session_start();
?>


<?php
	require('db.php');?>
<?php 
$sql = 'SELECT * FROM employee';
         $result = mysqli_query($con, $sql);

?>
<!doctype html>
    <html>
    <body>
        <h1 align="center">Employee Details</h1>
        <table border="1" align="center" style="line-height:25px;">
            <tr>
                <th> Namev</th>
                <th>Category</th>
                <th>Phone Number</th>
            </tr>
            <?php


         if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                ?>
            <tr>
                <td><?php echo $row["e_name"];?></td>
                <td><?php echo $row["category"];?></td>
                <td><?php echo $row["mobile"];?></td>                
             </tr>
            <?php
              
            }
         }
            else
            {
                ?>
            <tr>
                <th colspan="2">0 Results :::</th>
            </tr>
            <?php                
               }
            ?>
        </table>
        </body>
</html>
