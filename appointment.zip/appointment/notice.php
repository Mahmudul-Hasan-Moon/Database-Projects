<?php
require('header.php');
/*if(isset($_SESSION["adminname"])){
 header('Location:index.php');
	}*/
?><!DOCTYPE html>
<html>
	<head>
		<title>This is title</title>
		<link href="notice.css" rel="stylesheet" type="text/css"/>
	</head>
	<body>
		<div class="main">
			<div class="left_part">
				<img src="4.jpg" alt=""/>
				<h2> !! CAREFUL ABOUT THE MEDICINE !!</h2>

				<p> We are kindly informed to our customers that some necessary medicines which are available in market are DUPLICATE which can harm and has many side effects . So be careful while buying medicines and must check the trade name. Also some medicines are made available which was already expired. So we kindly inform you check TRADE NAME and EXPIRY DATE before buying the medicine.Our duty is to provide you quality services<br>
				 THank You</p>
			</div>
			<div class="middle_part">
				<img src="cd.jpg" alt=""/>
				<h2>About our UNAVAILABLE Services</h2>

				<p>Sorry from whole team !!.<br><br> Our OPD services has been stopped for 1 week due to some technical problem. we are trying our best for restarting this services as soon as possible. So we cannot take appoinment for OPD services.<br>
					In our Blood Bank O-Positive group blood are lacking. we are sorry to say that but we are managing this and we will inform you as soon as it will available. 


				</p>

			</div>
            <div class="right_part">
				<img src="40.jpg" alt=""/>
				<h2>About our free services</h2>

				<p>Next week on friday we are going to provide all the medical services without any cost on the occasion of Birthday of our hospital.  


				</p>

			</div>
			<div class="right_part">
				<img src="ab.jpg" alt=""/>
				<h2> Unavailability of Doctor </h2>
				<p>Our CARDIOLOGY department DR. are unvailable tomorrow.
				due to change in climate his flight was canceled. so he will visit his tomorrow patient on friday. Time will be fixed later and informed to you.<br><br>

				THANKYOU

				</p>
			</div>
		</div>
	</body>
</html>










