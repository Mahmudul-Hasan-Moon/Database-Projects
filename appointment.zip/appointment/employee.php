<?php

require('header.php');
?>


<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_POST['submit'])){
    	$employee_id = stripslashes($_REQUEST['employee_id']);
		$employee_id = mysqli_real_escape_string($con,$employee_id);
		$e_name = stripslashes($_REQUEST['e_name']); // removes backslashes
		$e_name = mysqli_real_escape_string($con,$e_name); //escapes special characters in a string
		$nid = stripslashes($_REQUEST['nid']);
		$nid = mysqli_real_escape_string($con,$nid);
		$category = stripslashes($_REQUEST['category']);
		$category = mysqli_real_escape_string($con,$category);
		$salary = stripslashes($_REQUEST['salary']); // removes backslashes
		$salary = mysqli_real_escape_string($con,$salary); //escapes special characters in a string
		$mobile = stripslashes($_REQUEST['mobile']); // removes backslashes
		$mobile = mysqli_real_escape_string($con,$mobile); //escapes special characters in a string
		

	
        $query = "INSERT into `employee` (employee_id,e_name, nid, category, salary, mobile) VALUES ('$employee_id','$e_name',
         '$nid', '$category', '$salary', '$mobile')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>Data inserted successfully.</h3></div>";
        }
    }else{
?>
<div class="form">
<h1>Insert Employees Information</h1>
<form name="registration" action="" method="post">
<input type="text" name="employee_id" placeholder="Employee ID" required /><br>
<input type="text" name="e_name" placeholder="Employee Name" required /><br>
<input type="text" name="nid" placeholder="National ID" required /><br>
<input type="text" name="category" placeholder="Category" required /><br>
<input type="text" name="salary" placeholder="Salary" required /><br>
<input type="text" name="mobile" placeholder="Mobile" required />
<input type="submit" name="submit" value="Register" />
</form>

</div>
<?php } ?>
<body style="background:url(b.jpg);">

</body>
</html>
