<?php
session_start();


?>
<link rel="stylesheet" href="css/style.css" />
<meta charset="utf-8">

<ul class="menu">
  <li><a class="active" href="dh.php">Home</a></li>
  <?php if(isset($_SESSION["username"])){?>

 
  <
  <li class="dropbtn">View Data
  	<ul class="dropdown-content">
	  <li><a href="viewdoctor.php">Doctor Table</a></li>
	  <li><a href="viewpatient.php">Patient Table</a></li>
  	</ul>



  </li>
    <li><a href="logout.php">Logout</a></li>

  <?php } ?>
  <?php if(!isset($_SESSION["username"])){?>
  	<li><a href="login.php">Doctor</a></li>
  <?php } ?>
  <li><a href="dview.php">Search</a></li>
  <li><a href="dnotice.php">Notice</a></li>
    <li><a href="dvs.php">Schedule</a></li>
         <?php if(isset($_SESSION["username"])){?>

  <?php } ?>
  <?php if(!isset($_SESSION["username"])){?>
  	<li><a href="d-log.php">Doctor</a></li>
  <?php } ?>

</li>
 
</ul>


