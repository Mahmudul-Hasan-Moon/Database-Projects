<?php

require('header.php');
//session_start();
?>


<!DOCTYPE html>
<html>
<div class="btn-search">
   <form role="search" method="post">
    <div class="search-control">
      <p>  </p>
        <input type="search" Id="site-search" name="search"
               placeholder="Search Patient by Phn NO.">
        <button>Search</button>
    </div>
   </form>
</div>
</html>



<?php
   
	require('db.php');

   if(isset($_POST['search'])){
      $Id=trim($_POST['search']);
   
      $sql = "SELECT * FROM patient WHERE phn_no = $Id";

         $result = mysqli_query($con, $sql);
         $rows = mysqli_num_rows($result);
         
         if (!($rows==0)) {
            while($row = mysqli_fetch_assoc($result)) {
               echo "Serial Number : " . $row["Id"]. "<br>";
               echo "Name: " . $row["name"]. "<br>";
               echo "Date : " . $row["date"]. "<br>";
               
            }
         } else {
            echo "Your Data is not in this Database";
         }
   }
?>

