<?php
require('header.php');
/*if(isset($_SESSION["adminname"])){
 header('Location:index.php');
	}*/
?><!DOCTYPE html>
<html>
	<head>
		<title>Images</title>
		<link href="GalaryStyle.css" rel="stylesheet" type="text/css"/>
	</head>
	<body>
         <h1 align="center">Welcome to our Galary</h1>
		<div class="transition">
			<img src="1.jpg" alt=""/>
			<img src="2.jpg" alt=""/>
			<img src="3.jpg" alt=""/>
			<img src="4.jpg" alt=""/>
			<img src="5.jpg" alt=""/>
			<img src="6.jpg" alt=""/>
			<img src="7.jpg" alt=""/>
			
		</div>
	</body>
</html>