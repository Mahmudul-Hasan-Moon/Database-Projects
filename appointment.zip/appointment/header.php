<?php
session_start();


?>
<link rel="stylesheet" href="css/style.css" />
<meta charset="utf-8">

<ul class="menu">
  <li><a class="active" href="index.php">Home</a></li>
  <?php if(isset($_SESSION["username"])){?>

 
  <li class="dropbtn"> Data Entry
  	<ul class="dropdown-content">
	  <li><a href="doctor.php">Doctor Table</a></li>
	  <li><a href="employee.php">Employee Table</a></li>
    <li><a href="s.php">Schedule Table</a></li>
  	</ul>

  </li>
  <li class="dropbtn">View Data
  	<ul class="dropdown-content">
	  <li><a href="Aviewdoctor.php">Doctor Table</a></li>
	  <li><a href="viewemployee.php">Employee Table</a></li>
	  <li><a href="Aviewpatient.php">Patient Table</a></li>
  	</ul>

 </li>
    <li><a href="result.php">Search</a></li>
  <li><a href="notice.php">Notice</a></li>
    <li><a href="vs.php">Schedule</a></li>
 <li><a href="Galary.php">Galary</a></li>
    
    <li><a href="logout.php">Logout</a></li>

  <?php } ?>
  <?php if(!isset($_SESSION["username"])){?>
  	<li><a href="login.php">Admin</a></li>
  <?php } ?>

 
     
    <?php if(isset($_SESSION["username"])){?>

  <?php } ?>
  <?php if(!isset($_SESSION["username"])){?>
    
   
    
    <li class="dropbtn"> Patient
  	<ul class="dropdown-content">
        <li><a href="try.php">Register</a></li>
     </ul>
  </li>
   
    
    
  <?php }?>

    
         <?php if(isset($_SESSION["username"])){?>

  <?php } ?>
  <?php if(!isset($_SESSION["username"])){?>
  	<li><a href="d-log.php">Doctor</a></li>
  <?php } ?>

</li>
 
  <li><a href="about.php">About</a></li>
</ul>


