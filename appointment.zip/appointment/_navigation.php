            <div class="space">
                <a href="ph.php">Patient</a>
                |
                <a href="d-log.php">Doctor</a>
                |
                <a href="login.php">Admin</a>
            </div>
