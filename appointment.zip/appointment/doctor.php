<?php

require('header.php');
?>


<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_POST['submit'])){
    	$d_id = stripslashes($_REQUEST['d_id']);
		$d_id = mysqli_real_escape_string($con,$d_id);
		$name = stripslashes($_REQUEST['name']); // removes backslashes
		$name = mysqli_real_escape_string($con,$name); //escapes special characters in a string
		/*$fathers_name = stripslashes($_REQUEST['fathers_name']); // removes backslashes
		$fathers_name = mysqli_real_escape_string($con,$fathers_name); //escapes special characters in a string
		$mothers_name = stripslashes($_REQUEST['mothers_name']); // removes backslashes
		$mothers_name = mysqli_real_escape_string($con,$mothers_name); //escapes special characters in a string*/
		$address = stripslashes($_REQUEST['address']);
		$address = mysqli_real_escape_string($con,$address);
		$nid = stripslashes($_REQUEST['nid']);
		$nid = mysqli_real_escape_string($con,$nid);
		$phn_no = stripslashes($_REQUEST['phn_no']);
		$phn_no = mysqli_real_escape_string($con,$phn_no);
		$category = stripslashes($_REQUEST['category']);
		$category = mysqli_real_escape_string($con,$category);
		$email = stripslashes($_REQUEST['email']); // removes backslashes
		$email = mysqli_real_escape_string($con,$email); //escapes special characters in a string
		$quali = stripslashes($_REQUEST['quali']); // removes backslashes
		$quali = mysqli_real_escape_string($con,$quali); //escapes special characters in a string
		

	
        $query = "INSERT into `doctor` (d_id,name,address, nid,phn_no,category,email,quali) VALUES ('$d_id','$name','$address','$nid','$phn_no','$category', '$email', '$quali')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>Data inserted successfully.</h3></div>";
        }
    }else{
?>
<div class="form">
<h1>Insert Doctors Information</h1>
<form name="registration" action="" method="post">
<input type="text" name="d_id" placeholder="Doctor ID" required /><br>
<input type="text" name="name" placeholder="Name" required /><br>
<!-- <input type="text" name="fathers_name" placeholder="Fathers Name" required />
<input type="text" name="mothers_name" placeholder="Mothers Name" required /> -->
<input type="text" name="address" placeholder="Address" required /><br>
<input type="text" name="nid" placeholder="National ID" required /><br>
<input type="text" name="phn_no" placeholder="Phone No" required /><br>
<input type="text" name="category" placeholder="Category" required /><br>
<input type="text" name="email" placeholder="E-mail" required /><br>
<input type="text" name="quali" placeholder="Qualification" required />
<input type="submit" name="submit" value="Submit" />
</form>

</div>
<?php } ?>
<body style="background:url(b.jpg);">

</body>
</html>
