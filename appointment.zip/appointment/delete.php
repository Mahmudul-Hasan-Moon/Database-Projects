<?php

require('ph.php');
//session_start();
?>
<div class="btn-search">
   <form role="search" method="post">
    <div class="search-control">
      <p>  </p>
        <input type="text" Id="site-search" name="delete"
               placeholder="Enter Phone no">
        <button>Delete</button>
    </div>
   </form>
</div>

<?php
	require('db.php');?>
<?php 


if(isset($_POST['delete'])){
      $Id=trim($_POST['delete']);
      
$sql = "DELETE FROM patient Where phn_no= $Id";
        // $result = mysqli_query($con, $sql);

if(mysqli_query($con, $sql)) {
            echo "record has been deleted sucessfully";
         } else {
            echo "Not found";
         }
       }
?>