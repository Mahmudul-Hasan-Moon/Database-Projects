<?php
session_start();


?>
<link rel="stylesheet" href="css/style.css" />
<meta charset="utf-8">

<ul class="menu">
  <li><a class="active" href="dh.php">Home</a></li>
  <?php if(isset($_SESSION["username"])){?>

 
  <
  <li class="dropbtn">View Data
  	<ul class="dropdown-content">
	  <li><a href="pviewdoctor.php">Doctor Table</a></li>
  	</ul>
</li>

    <li class="dropbtn"> Appointment
  	<ul class="dropdown-content">
	  <li><a href="patient.php">Book Appointment</a></li>
	  <li><a href="delete.php">Cancel appointment</a></li>
  	</ul>

  </li>


  </li>
    <li><a href="logout.php">Logout</a></li>

  <?php } ?>
  <?php if(!isset($_SESSION["username"])){?>
  	<li><a href="p-log.php">Patient</a></li>
  <?php } ?>
  <li><a href="pview.php">Search</a></li>
  <li><a href="pnotice.php">Notice</a></li>
    <li><a href="pvs.php">Schedule</a></li>
 <li><a href="pgallery.php">Galary</a></li>
  
         <?php if(isset($_SESSION["username"])){?>

  <?php } ?>
  <?php if(!isset($_SESSION["username"])){?>
  	<li><a href="p-log.php">Patient</a></li>
  <?php } ?>

</li>
 
</ul>
















