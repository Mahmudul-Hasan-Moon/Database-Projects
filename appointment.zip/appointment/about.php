
<?php

require('header.php');
?>


<div class="fix container">
<br>
<h2>About our service</h2>
<p>Facilities available:<br>
	1.Total 50 beds<br>
	2.24 hour Trauma and Emergency Care.<br>
	3.24 hour ambulance service.<br>
	4.OPD with all specialties.<br>
	5.2 Operating rooms.<br>
	6.24 hour diagnostic service.<br>
	7.24-hour Pharmacy.<br>
	8.24-hour Blood Bank.<br>
	9.Physical,Medicine and Rehabilitation Center.<br>
	10.Vaccination center.<br>
	11.Radial Lounge.
 </p><br><br>
</div>
				<footer>
					<div class="footer">
					
							<h2>Follow us on:</h2>
							<ul>
								<li><a href="#">Twitter</a></li>
								<li><a href="#">Facebook Page</a></li>
								<li><a href="https://www.youtube.com/">Youtube</a></li>		
							</ul>
					</div>
				</footer>
		</div>



