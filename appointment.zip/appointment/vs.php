<?php

require('header.php');
//session_start();
?>


<?php
	require('db.php');
?>
<?php 
$sql = 'SELECT * FROM s';
         $result = mysqli_query($con, $sql);
        
?>
<!doctype html>
    <html>
    <body>
        <h1 align="center">Doctors Schedule</h1>
        <table border="1" align="center" style="line-height:25px;">
            <tr>
                <th>Doctor Name</th>
                <th> Category</th>
                <th> Days</th>
                <th>Start time</th>
                <th>End time</th>
            </tr>
            <?php
            

         if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                ?>
            <tr>
                <td><?php echo $row["name"];?></td>
                <td><?php echo $row["category"];?></td>
                <td><?php echo $row["day"];?></td>
                <td><?php echo $row["st"];?></td>
              <td><?php echo $row["et"];?></td>
                </tr>
            <?php
              
            }
         }
            else
            {
                ?>
            <tr>
                <th colspan="2">There is no data found :::</th>
            </tr>
            <?php
                
        
         }
            ?>
        </table>
        </body>
</html>



